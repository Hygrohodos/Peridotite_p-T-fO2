# Comparative geothermometry of mantle xenoliths

Python implementation of the P–T–fO₂ and garnet Fe³⁺/ΣFe calculations
described in:

> Greene, J. (in prep.) *Estimating mantle xenolith oxygen fugacity*.

The code replaces a brittle Excel workbook (`SD1 - P-T-fO2.xlsm`) with a
single reproducible pipeline. Editable constants live in
`calculations/params.py` so the protocol can be varied without rewriting
the thermometers.

## What this repository does

1. Convert mineral oxide wt% to cations (6-O pyroxene, 12-O garnet, 4-O olivine).
2. Iterate CA91 pressure with TA98 two-pyroxene temperature.
3. Compute supporting thermometers (NG10, HA84, KR00, WZ07, NA09).
4. Screen four-phase peridotites for equilibrium:
   - four phases present
   - TA98 > 900 °C
   - |TA98 − NG10| < 80 °C
   - |KR00 − HA84 polynomial| < 100 °C
   - |WZ07 − HA84 line| < 50 °C
5. Estimate garnet Fe³⁺/ΣFe by iterating WZ07 (Fe²⁺ only) against TA98
   until TA98 − WZ07corr ≤ 22 °C, with
   `WZ07corr = WZ07 − 118 °C` (F1300o, Matjuschkin et al. 2014).
6. Apply the high-T empirical Fe³⁺ adjustment for TA98 ≥ 1130 °C.
7. Compute Δlog fO₂ (FMQ) after Stagno et al. (2013).

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python scripts/run_pipeline.py
python scripts/make_figures.py
```

Outputs:

- `data/derived/p-T-fO2.csv` — journal table (SampleID, location, craton,
  lithology, reference, P, T, screen flag, iterated and corrected XFe³⁺,
  Δlog fO₂ FMQ)
- `data/derived/screened_PT.csv` — full working table
- `docs/figures/Fig01_….png` through `Fig12_….png`

## Layout

```
calculations/          pipeline, thermometers, screening, Fe3+, fO2
scripts/run_pipeline.py
scripts/make_figures.py
scripts/plot_exp_ta98_wz07.py   Fig. 4 (experimental calibration)
data/master/xenolith_geochem.csv
data/master/kimberlite_locations.csv
data/incoming/experiments_20260913.csv
data/geotherm.xlsx              depth axis on P–fO2 figures
data/spatial/web/               Hasterok et al. (2022) geology for Fig. 1
docs/figures/                   current chapter figures
calculations/params.py          all numerical thresholds
```

Change a threshold in `params.py` and re-run the two scripts above.
You do not need to edit the thermometer implementations.

Default Fe³⁺ parameters:

| Parameter | Value | Meaning |
|---|---:|---|
| `xfe3_start` | 0.05 | starting garnet Fe³⁺/ΣFe |
| `dxfe3` | 0.001 | iterator step |
| `dt_match_c` | 22 | stop when TA98 − WZ07corr ≤ this (°C) |
| `wz07_offset_c` | 118 | flat WZ07 correction (°C), F1300o |
| `t_emp_min_c` | 1130 | high-T empirical Fe³⁺ adjustment below |

## Input table

See `data/master/DATA_DICTIONARY.md`. Minimum columns are Sample ID,
Location, Craton, Lithology, Reference, and major-element oxides for
cpx, opx, garnet, and olivine. Measured `garnet_Fe3+` is optional and
is used only for validation figures, not for the fO₂ of the full set.

## Figures (this snapshot)

| Figure | Content |
|---|---|
| 1 | Sampled kimberlite localities on Hasterok geology |
| 2 | Effect of unaccounted garnet Fe³⁺ on ol–gt KD and WZ07 (sample 21-2, 55 kbar) |
| 3 | Equilibrium screens |
| 4 | Experimental TA98 − WZ07 with measured garnet Fe³⁺ |
| 5 | Slave calibration: estimated vs measured Fe³⁺ |
| 6 | ΔT calibration |
| 7 | Optimal-ΔT Fe³⁺ |
| 8 | Stoichiometric Fe³⁺ (Quinn et al. 2016) |
| 9 | Kaapvaal + Siberian validation |
| 10 | Estimated vs measured fO₂ |
| 11 | P–fO₂ from measured Fe³⁺ |
| 12 | Estimated oxygen fugacity |

## Provenance

Thermometers and barometers: Brey & Köhler (1990), Taylor (1998),
Nimis & Grütter (2010), Harley (1984), Krogh Ravna (2000),
Wu & Zhao (2007), Nimis & Amundsen (2009), Carswell & Gibb / Carswell
(CA91). Garnet Fe³⁺ iteration follows the Comparative Geothermometry
sheet of SD1, with the WZ07 zero-point taken from Matjuschkin et al.
(2014) charge F1300o. Oxygen fugacity follows Stagno et al. (2013).
Geologic base map: Hasterok et al. (2022).

## Licence

MIT (see `LICENSE`). Please cite the paper if you use the code or the
derived xenolith P–T–fO₂ table.
