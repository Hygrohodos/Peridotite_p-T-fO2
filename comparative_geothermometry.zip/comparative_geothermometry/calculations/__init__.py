"""
Comparative geothermometry and oxybarometry for mantle xenoliths.

Python translation of the P–T–fO2 and garnet Fe3+ calculations described
in Greene (in prep.) and originally prototyped in SD1 - P-T-fO2.xlsm.

    from calculations import run_full_pipeline
    result, stats = run_full_pipeline("data/master/xenolith_geochem.csv")
"""

from .pipeline import run_full_pipeline, load_and_clean

__all__ = ["run_full_pipeline", "load_and_clean"]
